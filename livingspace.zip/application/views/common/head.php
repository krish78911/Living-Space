<!--
Project Name: Living Space
Developed By: Krishna Kumar Singh
Contact: krishnakumar791@gmail.com
-->

<!DOCTYPE html>
<html>
    <head>
        <title>LivingSpace</title>
	<!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="<?php echo base_url('bootstrap/css/bootstrap.min.css');?>">
        <!-- Optional theme -->
        <link rel="stylesheet" href="<?php echo base_url('bootstrap/css/bootstrap-theme.min.css');?>">
        <!-- Latest compiled and minified JavaScript -->
        <script src="<? echo base_url();?>assets/js/bootstrap.min.js"></script>	
	<link rel="stylesheet" href="<? echo base_url();?>assets/stylesheets/style.css">
    </head>
    <body>
	<div class="page">
	