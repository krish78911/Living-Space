            <footer>
		    	This is footer
            </footer>
        </div>
    </body>
</html>