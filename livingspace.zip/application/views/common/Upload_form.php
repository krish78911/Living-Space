<?php echo $error;?> 
<input type = "file" name = "userfile" size = "20" /> 
<br /><br /> 
<input type = "submit" value = "upload" /> 